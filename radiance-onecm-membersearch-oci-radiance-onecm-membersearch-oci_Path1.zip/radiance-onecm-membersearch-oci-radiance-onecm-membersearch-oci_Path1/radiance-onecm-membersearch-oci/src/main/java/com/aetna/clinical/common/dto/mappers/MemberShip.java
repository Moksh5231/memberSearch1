package com.aetna.clinical.common.dto.mappers;

import lombok.Data;

@Data
public class MemberShip {

    private String status;
    private EffectivePeriod effectivePeriod;
}
