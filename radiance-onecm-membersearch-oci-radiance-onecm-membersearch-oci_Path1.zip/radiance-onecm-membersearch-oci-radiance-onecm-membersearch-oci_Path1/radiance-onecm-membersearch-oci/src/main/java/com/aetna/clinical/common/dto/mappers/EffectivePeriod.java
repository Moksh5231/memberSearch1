package com.aetna.clinical.common.dto.mappers;

import lombok.Data;

@Data
public class EffectivePeriod {

    private String datetimeBegin;
    private String datetimeEnd;
}
