package com.aetna.clinical.common.client;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClient;

import com.aetna.clinical.common.dto.mappers.ReadMembersResponse;

public class MemberClient {

    private final RestClient restClient;

    MemberClient() {
        restClient = RestClient.builder()
            .baseUrl("https://qaapi01.aetna.com")
            .build();
    }

    public ResponseEntity<ReadMembersResponse> getMemberById(String memberId) {
        String pathVariable = "healthcare/qapath1/hcb/v6/members";
        ResponseEntity<ReadMembersResponse> response = restClient.get()
        
            .uri(uriBuilder -> uriBuilder
                 .path("/" + pathVariable)
                 .queryParam("memberId", memberId)
                 .build())
            .header("Content-Type", "application/json")
            .retrieve()
            .toEntity(ReadMembersResponse.class);

        return response;
    }

}
