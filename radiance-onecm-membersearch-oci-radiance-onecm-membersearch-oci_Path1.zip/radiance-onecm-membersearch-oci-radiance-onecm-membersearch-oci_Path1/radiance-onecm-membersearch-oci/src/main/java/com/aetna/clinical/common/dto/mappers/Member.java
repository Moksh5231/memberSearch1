package com.aetna.clinical.common.dto.mappers;

import lombok.Data;

@Data
public class Member {

    private Person person;
    private MemberShips memberShips;
}
