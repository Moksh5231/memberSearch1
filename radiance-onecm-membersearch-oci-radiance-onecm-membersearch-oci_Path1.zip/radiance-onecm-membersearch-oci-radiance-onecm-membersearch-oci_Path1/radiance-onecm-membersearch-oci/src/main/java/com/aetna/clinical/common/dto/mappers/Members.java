package com.aetna.clinical.common.dto.mappers;

import java.util.List;

import lombok.Data;

@Data
public class Members {

    private List<Member> member;
}
