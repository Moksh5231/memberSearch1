package com.aetna.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aetna.clinical.common.client.MemberClient;

@Service
public class MemberService {

    @Autowired
    private MemberClient memberClient;

public void getMemberById(String id)
{
    System.out.println(memberClient.getMemberById(id));
}

}
