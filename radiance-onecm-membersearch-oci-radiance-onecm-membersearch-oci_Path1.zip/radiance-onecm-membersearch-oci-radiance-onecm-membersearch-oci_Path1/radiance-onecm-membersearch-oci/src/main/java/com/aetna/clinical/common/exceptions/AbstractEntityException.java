/*
 * Created Dec 2007
 * Updated May 2009
 * Updated Mar 2010 (Java 5 code improvements)
 *//*

package com.aetna.clinical.common.exceptions;

*/
/**
 * <code>AbstractEntityException</code> is a base class for unchecked exceptions that describe
 * various technical and business errors that pertain to the domain model.  Note
 * that it's packaged with common code, which is intended to imply a lack of
 * dependency on other packages as well as its reusable nature (within various subsystems of the
 * application).
 * <p>
 * Note: The Spring Framework and various persistence frameworks offer their own persistence
 * exception hierarchies.  This class was created in support of stub DAO implementations.  
 * <p>
 * Note: This class exists as an example of how to package and deploy such components and is not
 * considered reusable across the enterprise (and thus not supported), although any application is
 * free to leverage this code.
 * 
 * @author Kent Rancourt
 * @author Tony Kerz
 *//*

public abstract class AbstractEntityException extends AbstractPersistenceException {

	private static final long serialVersionUID = -6149997519195128582L;
	
	private Class <?> type;
    private Integer id;
   
    */
/**
     * Constructor specifying the <code>Class</code> and <code>Integer</code> identifier of
     * the problematic domain object.
     * 
     * @param type the <code>Class</code> of the problematic domain object
     * @param id the <code>Integer</code> identifier of the problematic domain object
     *//*

    public AbstractEntityException(Class <?> type, Integer id) {
        super("");
        this.type = type;
        this.id = id;
    }
    
    */
/**
     * Returns the <code>Class</code> of the problematic domain object.  Combine this with the
     * <code>id</code> attribute to uniquely identify the problematic object.
     * 
     * @return the <code>Class</code> of the problematic domain object
     *//*

    public Class <?> getType() {
        return type;
    }
    
    */
/**
     * Returns an <code>Integer</code> identifier for the problematic domain object.  Combine this
     * with the <code>type</code> attribute to uniquely identify the problematic object.
     * 
     * @return the <code>Integer</code> identifier for the problematic domain object
     *//*

    public Integer getId() {
        return id;
    }
    
}*/
