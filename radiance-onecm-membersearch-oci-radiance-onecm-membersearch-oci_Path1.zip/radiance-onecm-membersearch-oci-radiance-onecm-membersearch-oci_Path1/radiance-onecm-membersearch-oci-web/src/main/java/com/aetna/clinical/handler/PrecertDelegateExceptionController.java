/*
package com.aetna.clinical.handler;

import com.aetna.clinical.radiance-onecm-membersearch.dto.response.PrecertDelegateResponse;
import com.aetna.clinical.radiance-onecm-membersearch.exception.PrecertDelegateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.NoSuchElementException;

@ControllerAdvice
public class PrecertDelegateExceptionController {
    final String CLASS_NAME="PrecertDelegateExceptionController";

    private static Logger logger = LoggerFactory.getLogger(PrecertDelegateExceptionController.class);

    //1100
    @ExceptionHandler(value = PrecertDelegateException.class)
    public ResponseEntity<Object> exception(PrecertDelegateException exception){
        String METHOD_NAME = "EapBenefitsException";
        logger.info("logType=\"ERROR_EXPECTED\", CLASS_NAME={}, METHOD_NAME={}, STATUS_CODE={}, TX_ID={}, EX_MSG={} INFO="+ exception.getMoreInformtion(),exception.getClassName(),exception.getMethodName(), "1100", exception.getTxId(), exception.getMessage());
        PrecertDelegateResponse precertDelegateResponse = new PrecertDelegateResponse();

        precertDelegateResponse.setHttpCode(exception.getCode());
        precertDelegateResponse.setHttpMessage(exception.getMessage());
        precertDelegateResponse.setMoreInformation(exception.getTxId() + "|" +exception.getClassName() + "|" +exception.getMethodName() + "|" +exception.getMoreInformtion());

        return new ResponseEntity<>(precertDelegateResponse, HttpStatus.BAD_REQUEST);
    }

    //1101
    @ExceptionHandler(value = NoSuchElementException.class)
    public ResponseEntity<Object> exception(NoSuchElementException exception){
        String METHOD_NAME = "NoSuchElementException";
        logger.info("logType=\"ERROR_UNEXPECTED\", CLASS_NAME={}, METHOD_NAME={}, STATUS_CODE={}, INFO="+ exception.getMessage(),CLASS_NAME,METHOD_NAME,"1101");
        PrecertDelegateResponse precertDelegateResponse = new PrecertDelegateResponse();

        precertDelegateResponse.setHttpCode("400");
        precertDelegateResponse.setHttpMessage("BAD REQUEST");
        precertDelegateResponse.setMoreInformation(exception.getMessage());

        return new ResponseEntity<>(precertDelegateResponse, HttpStatus.BAD_REQUEST);
    }

    //1102
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<Object> exception(MethodArgumentNotValidException exception){
        String METHOD_NAME = "MethodArgumentNotValidException";
        logger.info("logType=\"ERROR_UNEXPECTED\", CLASS_NAME={}, METHOD_NAME={}, STATUS_CODE={}, INFO="+ exception.getMessage(),CLASS_NAME,METHOD_NAME,"1102");
        PrecertDelegateResponse precertDelegateResponse = new PrecertDelegateResponse();

        precertDelegateResponse.setHttpCode("400");
        precertDelegateResponse.setHttpMessage("BAD REQUEST");
        precertDelegateResponse.setMoreInformation(exception.getMessage());

        return new ResponseEntity<>(precertDelegateResponse, HttpStatus.BAD_REQUEST);
    }

    //1103
    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Object> exception(Exception exception){
        String METHOD_NAME = "Generic";
        logger.info("logType=\"ERROR_UNEXPECTED\", CLASS_NAME={}, METHOD_NAME={}, STATUS_CODE={}, INFO="+ exception.getMessage(),CLASS_NAME,METHOD_NAME,"1103");
        PrecertDelegateResponse precertDelegateResponse = new PrecertDelegateResponse();

        precertDelegateResponse.setHttpCode("500");
        precertDelegateResponse.setHttpMessage("Internal Server Error");

        StringWriter sw = new StringWriter();
        exception.printStackTrace(new PrintWriter(sw));
        String exceptionDetails = sw.toString();

        precertDelegateResponse.setMoreInformation(exceptionDetails);

        return new ResponseEntity<>(precertDelegateResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
*/
