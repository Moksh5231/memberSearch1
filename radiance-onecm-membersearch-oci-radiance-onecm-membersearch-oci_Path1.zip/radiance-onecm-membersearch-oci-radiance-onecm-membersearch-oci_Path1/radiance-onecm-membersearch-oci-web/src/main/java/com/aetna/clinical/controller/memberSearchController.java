package com.aetna.clinical.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class memberSearchController{


    @PostMapping("/memberSearch")
      public Map<String, Object> testConnectionToSf()
    {
        Testing data = new Testing(1,"Sample API response  HELLO WORLD");
        Map<String, Object> response = new HashMap<String,Object>();
        response.put("data",data);
        response.put("status","success");
        response.put("message","Hello World");
        return response;
    }

}