package com.aetna.clinical.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aetna.service.MemberService;

import java.util.HashMap;
import java.util.Map;

@RestController
public class memberSearchController{

  @Autowired
  private MemberService memberService;

    @PostMapping("/memberSearch")
      public Map<String, Object> testConnectionToSf()
    {
        Testing data = new Testing(1,"Sample API response  HELLO WORLD");
        Map<String, Object> response = new HashMap<String,Object>();
        response.put("data",data);
        response.put("status","success");
        response.put("message","Hello World");
        return response;
    }

    @GetMapping("/member")
    public void getMemberById(@RequestParam ("id") String id){
      memberService.getMemberById(id);

    }

}