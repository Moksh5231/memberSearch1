package com.aetna.clinical.cee.providerenablement.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.IdCrossWalkRequestDTO;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.IdCrossWalkSearchRequest;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.IdCrossWalkSourceId;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.RequestAttributes;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response.IdCrossWalkResponseDTO;
import com.aetna.clinical.cee.providerenablement.exception.ProviderEnablementException;
import com.aetna.clinical.cee.providerenablement.util.CrosswalkAPICHelper;
import com.aetna.clinical.cee.providerenablement.util.DataConverter;
import com.aetna.clinical.cee.providerenablement.util.LoggerAsyncService;
import com.aetna.clinical.cee.providerenablement.util.ProviderEnablementConstant;

@Service
public class IdCrossWalkServiceImpl {
	private static Logger logger=LoggerFactory.getLogger(IdCrossWalkServiceImpl.class);

	@Autowired
	LoggerAsyncService asyncLogger;

	@Autowired
    private DataConverter objectConverter;

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	CrosswalkAPICHelper crosswalkAPICHelper;
	
	public IdCrossWalkResponseDTO getCrosswalkResponse(String crosswalkAPICUrl,
			String transactionId, String memberId) {
		IdCrossWalkResponseDTO crosswalkResponse=null;
	    //String crosswalkResponseStatus = null;
	    int statusCode;
	   // ArrayList<Object> crossWalkResponseList = new ArrayList<>();
		try {
			IdCrossWalkRequestDTO idCrossWalkRequest= prepareCrosswalkRequest(memberId);
	    	//logger.info("call to crosswalk micro service start for the Transaction Id {},idcrosswalk request - {}, url - {}",transactionId,objectConverter.convertToJson(idCrossWalkRequest),crosswalkAPICUrl);
	    	asyncLogger.logService("call to crosswalk micro service start for the Transaction Id - {}, idcrosswalk request - {}", logger, transactionId, objectConverter.convertToJson(idCrossWalkRequest));
	    	logger.info("Crosswalk APIC URL  for the Transaction Id - {}, url - {}",transactionId,crosswalkAPICUrl);
	    	//direct call
	    	//ResponseEntity<IdCrossWalkResponseDTO> crossWalkServiceResponse=restTemplate.postForEntity(crosswalkServiceUrl, idCrossWalkRequest, IdCrossWalkResponseDTO.class);
	    	//APIC call
	    	StopWatch crossWalkTime = new StopWatch();
	    	crossWalkTime.start();
	    	
			HttpHeaders httpHeaders = crosswalkAPICHelper.buildCrosswalkHttpHeader();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			HttpEntity<IdCrossWalkRequestDTO> crosswalkEntity = new HttpEntity<>(idCrossWalkRequest, httpHeaders);
			ResponseEntity<IdCrossWalkResponseDTO> crossWalkServiceResponse = restTemplate.postForEntity(crosswalkAPICUrl, crosswalkEntity, IdCrossWalkResponseDTO.class);
			crossWalkTime.stop();
			//logger.info("call to crosswalk micro service finish for Transaction Id {}, URL {}, CrossWalkResponseTime - {}, crosswalk service response {}", transactionId, crosswalkAPICUrl, crossWalkTime.getTime(TimeUnit.MILLISECONDS), objectConverter.convertToJson(crossWalkServiceResponse));
			asyncLogger.logServiceStatements("call to crosswalk micro service finish for Transaction Id - {}, ResponseTime - {} ms, response - {}", logger, transactionId, crossWalkTime, objectConverter.convertToJson(crossWalkServiceResponse));
			statusCode=crossWalkServiceResponse.getStatusCodeValue();
	    	if(statusCode==200) {
	    		crosswalkResponse=crossWalkServiceResponse.getBody();
	    		//logger.info("crossWalk response success for transaction Id {}, response message {}",transactionId, objectConverter.convertToJson(crosswalkResponse));
	    		//crosswalkResponseStatus=crosswalkResponse.getIdCrossWalkSearchResponse().getIdCrossWalkSearchStatus().getStatusMessage();
	    		
	    		//crossWalkResponseList.add(crosswalkResponse);
	    		//crossWalkResponseList.add(crosswalkResponseStatus);
	    		//logger.info("cross walk response success for Transaction Id {}, proxy id {}, success message {}>> , response - {}",transactionId,proxyMemberId,crosswalkResponseStatus, objectConverter.convertToJson(crosswalkResponse));
	    	}
	    	
	    }catch(HttpStatusCodeException statusException) {
	    	logger.error("Error in crosswalk service call for Transaction Id - {}, error message - {}", transactionId,statusException.getResponseBodyAsString());
	    	/*String responseBody=statusException.getResponseBodyAsString();
	    	logger.error("Error in crosswalk service call for transaction id {}, proxy id {}>>, error message {}>>", transactionId, proxyMemberId, responseBody);
	    	MemberAppointmentsErrorResponse crosswalkErrorResponse = (MemberAppointmentsErrorResponse) objectConverter.jsonToObject(responseBody, MemberAppointmentsErrorResponse.class);
			throw new MemberAppointmentsException(crosswalkErrorResponse.getHttpCode(), crosswalkErrorResponse.getHttpMessage(), crosswalkErrorResponse.getMoreInformation());*/
	    	//throw new MemberAppointmentsException(MemberAppointmentsConstant.CODE_500, MemberAppointmentsConstant.CODE_500_MESSAGE,MemberAppointmentsConstant.CODE_CROSSWALK_ERROR_INFO);
	    	
	    	HttpStatus status = statusException.getStatusCode();
 	       	if(status == HttpStatus.NOT_FOUND) {
 	       		throw new ProviderEnablementException(ProviderEnablementConstant.CODE_404, ProviderEnablementConstant.CODE_404_MESSAGE,ProviderEnablementConstant.CODE_404_INFO);
 	       	}else {
 	       		throw new ProviderEnablementException(ProviderEnablementConstant.CODE_500, ProviderEnablementConstant.CODE_500_MESSAGE,ProviderEnablementConstant.CODE_CROSSWALK_ERROR_INFO);
 	       	}
	    }catch (ProviderEnablementException providerEnablementException) {
			logger.error("MemberAppointmentsException in Crosswalk service for Transaction Id - {}, error message - {}", transactionId, providerEnablementException.getMoreInformation());
			throw providerEnablementException;
			
		}catch(Exception genericException) {
			logger.error("GenericException in getCrosswalkResponse for Transaction Id - {}, error message {}>>>" ,transactionId, genericException.getMessage());
			genericException.printStackTrace();
			throw genericException;
		}
		//asyncLogger.logService("crossWalk response  for transaction Id - {}, response - {}", logger, transactionId, objectConverter.convertToJson(crosswalkResponse));
		return crosswalkResponse;
	
	}
	
private IdCrossWalkRequestDTO prepareCrosswalkRequest(String memberId) {
		
		SimpleDateFormat sdf = new SimpleDateFormat(ProviderEnablementConstant.CROSSWALK_ASOFDATE_FORMAT);
		
		Date asOfDate = new Date();
		
		IdCrossWalkRequestDTO crosswalkRequest = new IdCrossWalkRequestDTO();
		IdCrossWalkSearchRequest idCrossWalkSearchRequest = new IdCrossWalkSearchRequest();
		
		RequestAttributes requestAttributes = new RequestAttributes();
		requestAttributes.setApplicationID("CI-CEE-C360");
		requestAttributes.setSearchReqID("RequestSample");
		
		List<IdCrossWalkSourceId> memberCrosswalkIdList = new ArrayList<IdCrossWalkSourceId>();
		IdCrossWalkSourceId memberCrosswalkId = new IdCrossWalkSourceId();
		memberCrosswalkId.setIdType("preferredProxyId");
		memberCrosswalkId.setIdValue(memberId);
		//memberCrosswalkId.setResourceId(preferredIDType+"~"+memberId);  --need to check with Kumar on preferred ProxyId
		memberCrosswalkId.setResourceId("15"+"~"+memberId);
		//memberCrosswalkId.setIdSource(preferredIDType);
		memberCrosswalkId.setIdSource("15");
		memberCrosswalkId.setSourceSystemQualifier("IM");
		
		memberCrosswalkIdList.add(memberCrosswalkId);
		idCrossWalkSearchRequest.setIdCrossWalkSourceId(memberCrosswalkIdList);
		idCrossWalkSearchRequest.setAsOfdate(sdf.format(asOfDate));
		idCrossWalkSearchRequest.setRequestAttributes(requestAttributes);
		crosswalkRequest.setIdCrossWalkSearchRequest(idCrossWalkSearchRequest);
		
		return crosswalkRequest;
	}


}
