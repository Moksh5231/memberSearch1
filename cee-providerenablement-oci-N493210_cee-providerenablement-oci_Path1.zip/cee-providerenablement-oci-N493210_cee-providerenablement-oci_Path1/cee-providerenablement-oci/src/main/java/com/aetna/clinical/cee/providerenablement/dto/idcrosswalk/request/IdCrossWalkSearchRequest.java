package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request;

import java.util.List;

public class IdCrossWalkSearchRequest {
	
	
	private RequestAttributes requestAttributes;

    private List<IdCrossWalkSourceId> idCrossWalkSourceId;

    private String asOfdate;

    private String lineOfBusiness;

    private String firstName;

    private String lastName;

    private String dob;

	public RequestAttributes getRequestAttributes() {
		return requestAttributes;
	}

	public void setRequestAttributes(RequestAttributes requestAttributes) {
		this.requestAttributes = requestAttributes;
	}

	public List<IdCrossWalkSourceId> getIdCrossWalkSourceId() {
		return idCrossWalkSourceId;
	}

	public void setIdCrossWalkSourceId(List<IdCrossWalkSourceId> idCrossWalkSourceId) {
		this.idCrossWalkSourceId = idCrossWalkSourceId;
	}

	public String getAsOfdate() {
		return asOfdate;
	}

	public void setAsOfdate(String asOfdate) {
		this.asOfdate = asOfdate;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}


}
