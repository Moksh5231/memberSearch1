package com.aetna.clinical.cee.providerenablement.dto.request;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "idSource",
        "idType",
        "idValue",
        "resourceId"
})

public class MemberID {

    @JsonProperty("idSource")
    private String idSource;
    @JsonProperty("idType")
    private String idType;
    @JsonProperty("idValue")
    private String idValue;
    @JsonProperty("resourceId")
    private String resourceId;

    @JsonProperty("idSource")
    public String getIdSource() {
        return idSource;
    }

    @JsonProperty("idSource")
    public void setIdSource(String idSource) {
        this.idSource = idSource;
    }

    @JsonProperty("idType")
    public String getIdType() {
        return idType;
    }

    @JsonProperty("idType")
    public void setIdType(String idType) {
        this.idType = idType;
    }

    @JsonProperty("idValue")
    public String getIdValue() {
        return idValue;
    }

    @JsonProperty("idValue")
    public void setIdValue(String idValue) {
        this.idValue = idValue;
    }

    @JsonProperty("resourceId")
    public String getResourceId() {
        return resourceId;
    }

    @JsonProperty("resourceId")
    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

}