package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response;

public class IdCrossWalkResponseDTO {
	
	private IdCrossWalkSearchResponse idCrossWalkSearchResponse;

	public IdCrossWalkSearchResponse getIdCrossWalkSearchResponse() {
		return idCrossWalkSearchResponse;
	}

	public void setIdCrossWalkSearchResponse(IdCrossWalkSearchResponse idCrossWalkSearchResponse) {
		this.idCrossWalkSearchResponse = idCrossWalkSearchResponse;
	}

}
