package com.aetna.clinical.cee.providerenablement.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.nio.file.Files;
import java.util.Map;

@Component
public class DataConverter {
    private static Logger logger = LoggerFactory.getLogger(DataConverter.class);

    ObjectMapper objectMapper = new ObjectMapper();

    public String convertToJson(Object inputObject) {
        String resultData = null;
        try {
            resultData = objectMapper.writeValueAsString(inputObject);
        } catch (JsonProcessingException e) {
            logger.error("Error in converting object to json - {}, error message - {}", inputObject.toString(), e);
        }
        return resultData;
    }

    public Object jsonToObject(String jsonString, Class<?> targetObject) {
        Object resultObject = null;
        try {
            resultObject = objectMapper.readValue(jsonString, targetObject);
        }catch(Exception e) {
            logger.error("Error in converting json to object - {} - error message {}>>>", jsonString,e);
        }
        return resultObject;
    }

    public Object objectToObject(Object jsonObject, Class<?> targetObject) {
        Object resultObject = null;
        try {
            resultObject = objectMapper.convertValue(jsonObject, targetObject);
        }catch(Exception e) {
            logger.error("Error in converting json to object - {} - error message {}>>>", jsonObject,e);
        }
        return resultObject;
    }

    public Map<String, Map<String, String>> jsonToMap(String jsonString) {
        Map<String, Map<String, String>> resultData = null;
        try {
            resultData = objectMapper.readValue(jsonString, new TypeReference<Map<String, Map<String, String>>>() {});
        } catch(Exception e) {
            logger.error("Error in converting json to map - {} - error message {}>>>", jsonString,e);
        }
        return resultData;
    }


    public static String removeSuffix(String inputString, String suffixToRemove) {
        if(StringUtils.isNotBlank(inputString)) {
            if(inputString.indexOf(suffixToRemove)!=-1) {
                inputString = inputString.substring(0, inputString.indexOf(suffixToRemove));
            }
        }
        return inputString;
    }

    public String readFileAsString(String filename)throws Exception {
        File file = ResourceUtils.getFile("classpath:"+filename);
        String json = "";
        {
            json = new String(Files.readAllBytes(file.toPath()));
        }
        return json;
    }

    public String replacePathVariable(String url,String pathValue){
        String returnVal=url.substring(0,url.indexOf("{"))+pathValue+url.substring(url.indexOf("}")+1,url.length());
        return returnVal;
    }

    public Object jsonToObjectWithUnknownProperties(String jsonString, Class<?> targetObject) {
        Object resultObject = null;
        try {
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//            objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY,true);
            resultObject = objectMapper.readValue(jsonString, targetObject);
        }catch(Exception e) {
            logger.error("Error in converting json to object - {} - error message {}>>>", jsonString,e);
        }
        return resultObject;
    }
}
