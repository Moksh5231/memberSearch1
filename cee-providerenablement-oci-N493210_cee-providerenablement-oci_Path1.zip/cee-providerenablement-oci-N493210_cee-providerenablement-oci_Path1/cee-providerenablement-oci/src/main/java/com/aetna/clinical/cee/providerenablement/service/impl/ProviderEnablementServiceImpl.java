package com.aetna.clinical.cee.providerenablement.service.impl;

import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.IdCrossWalkRequestDTO;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.IdCrossWalkSearchRequest;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.IdCrossWalkSourceId;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.RequestAttributes;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response.IdCrossWalkResponseDTO;
import com.aetna.clinical.cee.providerenablement.dto.memberdelegation.request.MemberDelegationRequestDTO;
import com.aetna.clinical.cee.providerenablement.dto.memberdelegation.response.MemberDelegationResponseDTO;
import com.aetna.clinical.cee.providerenablement.dto.request.ReadProviderEnablementRequest;
import com.aetna.clinical.cee.providerenablement.dto.response.ReadProviderEnablementResponse;
import com.aetna.clinical.cee.providerenablement.exception.ProviderEnablementException;
import com.aetna.clinical.cee.providerenablement.util.DataConverter;
import com.aetna.clinical.cee.providerenablement.util.LoggerAsyncService;
import com.aetna.clinical.cee.providerenablement.util.ProviderEnablementConstant;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ProviderEnablementServiceImpl {
    final String CLASS_NAME = "ProviderEnablementServiceImpl";
    private static Logger logger = LoggerFactory.getLogger(ProviderEnablementServiceImpl.class);

    @Autowired
    private DataConverter objectConverter;

    @Autowired
	LoggerAsyncService asyncLogger;
    
    
    @Autowired
    private IdCrossWalkServiceImpl idCrossWalkServiceImpl;

    @Autowired
    private MemberDelegationServiceImpl memberDelegationServiceImpl;
    
    @Value("${crosswalk.apic.Url}")
	private String crosswalkAPICUrl;

    public ReadProviderEnablementResponse SaveProviderEnablementDetails(String transactionId,String memberId){
        final String METHOD_NAME = "SaveProviderEnablementDetails";
        String preferredGlobalID = null;
        
        ReadProviderEnablementResponse providerEnablementResponse=null;        
        //MemberDelegationResponseDTO memberDelegationResponseDTO = null;
         // Expand this with neccessary mapping and flow logic and validations as per Orchestration
        try {        
		//String crosswalkAPICUrl=servicesByTopic.getUrl();
		
        IdCrossWalkResponseDTO crosswalkResponse = idCrossWalkServiceImpl.getCrosswalkResponse(crosswalkAPICUrl,transactionId,memberId);
		//crosswalkResponse = getCrosswalkSampleResponse(idCrossWalkRequest,crosswalkAPICUrl,transactionId,proxyMemberId);
		preferredGlobalID = processCrosswalkResponse(crosswalkResponse, transactionId);		
		MemberDelegationResponseDTO memberDelegationResponseDTO = memberDelegationServiceImpl.getMemberDelegationDetails(preferredGlobalID, transactionId);
		
		//providerEnablementResponse = processProviderEnablementResponse();
		
        }
        catch(ProviderEnablementException providerEnablementException) {
			logger.error("METHODNAME={}, ProviderEnablementException in Provider Enablement service layer for Transaction Id - {},  error message - {}>>>", METHOD_NAME, transactionId, providerEnablementException.getMoreInformation());
			throw providerEnablementException;
			
		}catch(Exception genericException) {
			logger.error("METHODNAME={}, GenericException in member appointments service layer for Transaction Id - {}, error message - {}>>>" , METHOD_NAME, transactionId, genericException.getMessage());
			throw genericException;
		}
		
        return providerEnablementResponse;
    }

	private String processCrosswalkResponse(IdCrossWalkResponseDTO crosswalkResponse, String transactionId) {
		
		String globalId = null;;
		//String globalId = crosswalkResponse.getIdCrossWalkSearchResponse().getMatchedMemberRecords().getMemberUniqueIdentifiers().getPreferredGlobalID();
		if(null != crosswalkResponse.getIdCrossWalkSearchResponse() &&
				null != crosswalkResponse.getIdCrossWalkSearchResponse().getMatchedMemberRecords() &&
					null != crosswalkResponse.getIdCrossWalkSearchResponse().getMatchedMemberRecords().getMemberUniqueIdentifiers() &&
						null != crosswalkResponse.getIdCrossWalkSearchResponse().getMatchedMemberRecords().getMemberUniqueIdentifiers().getPreferredGlobalID()) {
			globalId = crosswalkResponse.getIdCrossWalkSearchResponse().getMatchedMemberRecords().getMemberUniqueIdentifiers().getPreferredGlobalID();
			
		}
		return globalId;
	}

	private IdCrossWalkRequestDTO prepareCrosswalkRequest(String memberId) {
		
		SimpleDateFormat sdf = new SimpleDateFormat(ProviderEnablementConstant.CROSSWALK_ASOFDATE_FORMAT);
		
		Date asOfDate = new Date();
		
		IdCrossWalkRequestDTO crosswalkRequest = new IdCrossWalkRequestDTO();
		IdCrossWalkSearchRequest idCrossWalkSearchRequest = new IdCrossWalkSearchRequest();
		
		RequestAttributes requestAttributes = new RequestAttributes();
		requestAttributes.setApplicationID("CI-CEE-C360");
		requestAttributes.setSearchReqID("RequestSample");
		
		List<IdCrossWalkSourceId> memberCrosswalkIdList = new ArrayList<IdCrossWalkSourceId>();
		IdCrossWalkSourceId memberCrosswalkId = new IdCrossWalkSourceId();
		memberCrosswalkId.setIdType("preferredProxyId");
		memberCrosswalkId.setIdValue(memberId);
		//memberCrosswalkId.setResourceId(preferredIDType+"~"+memberId);  --need to check with Kumar on preferred ProxyId
		memberCrosswalkId.setResourceId("15"+"~"+memberId);
		//memberCrosswalkId.setIdSource(preferredIDType);
		memberCrosswalkId.setIdSource("15");
		memberCrosswalkId.setSourceSystemQualifier("IM");
		
		memberCrosswalkIdList.add(memberCrosswalkId);
		idCrossWalkSearchRequest.setIdCrossWalkSourceId(memberCrosswalkIdList);
		idCrossWalkSearchRequest.setAsOfdate(sdf.format(asOfDate));
		idCrossWalkSearchRequest.setRequestAttributes(requestAttributes);
		crosswalkRequest.setIdCrossWalkSearchRequest(idCrossWalkSearchRequest);
		
		return crosswalkRequest;
	}

	}
