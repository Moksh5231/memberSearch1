/*
 * Created Dec 2007
 * Updated May 2009
 */
package com.aetna.clinical.cee.common.exceptions;

/**
 * <code>PersistenceConstraintViolationException</code> is an unchecked exceptions that describe
 * scenarios where logical constraints on a real or dummy database have been violated (e.g. a field
 * which must have a unique value contains a duplicate value).
 * <p>
 * Note: The Spring Framework and various persistence frameworks offer their own persistence
 * exception hierarchies.  This class was created in support of stub DAO implementations.  
 * <p>
 * Note: This class exists as an example of how to package and deploy such components and is not
 * considered reusable across the enterprise (and thus not supported), although any application is
 * free to leverage this code.
 * 
 * @author Kent Rancourt
 * @author Tony Kerz
 */
public class PersistenceConstraintViolationException extends AbstractPersistenceException {

    private static final long serialVersionUID = 7315100298291156879L;

    public PersistenceConstraintViolationException(String message) {
        super(message);
    }
    
}
