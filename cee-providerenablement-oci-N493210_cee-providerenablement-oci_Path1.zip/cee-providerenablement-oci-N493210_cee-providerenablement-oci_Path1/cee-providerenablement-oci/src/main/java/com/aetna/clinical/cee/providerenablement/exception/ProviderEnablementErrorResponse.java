package com.aetna.clinical.cee.providerenablement.exception;

public class ProviderEnablementErrorResponse {
    private String httpCode;
    private String httpMessage;
    private String moreInformation;

    public ProviderEnablementErrorResponse() {}

    public ProviderEnablementErrorResponse(String httpCode, String httpMessage, String moreInformation) {
        super();
        this.httpCode = httpCode;
        this.httpMessage = httpMessage;
        this.moreInformation = moreInformation;
    }

    public String getHttpCode() {
        return httpCode;
    }

    public void setHttpCode(String httpCode) {
        this.httpCode = httpCode;
    }

    public String getHttpMessage() {
        return httpMessage;
    }

    public void setHttpMessage(String httpMessage) {
        this.httpMessage = httpMessage;
    }

    public String getMoreInformation() {
        return moreInformation;
    }

    public void setMoreInformation(String moreInformation) {
        this.moreInformation = moreInformation;
    }

    @Override
    public String toString() {
        return "ProviderEnablementErrorResponse{" +
                "httpCode='" + httpCode + '\'' +
                ", httpMessage='" + httpMessage + '\'' +
                ", moreInformation='" + moreInformation + '\'' +
                '}';
    }
}
