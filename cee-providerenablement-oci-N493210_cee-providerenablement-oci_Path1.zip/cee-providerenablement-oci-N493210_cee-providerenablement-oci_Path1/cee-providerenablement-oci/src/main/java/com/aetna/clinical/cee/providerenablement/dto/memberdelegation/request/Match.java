
package com.aetna.clinical.cee.providerenablement.dto.memberdelegation.request;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "src_member_id"
})
@Generated("jsonschema2pojo")
public class Match {

    @JsonProperty("src_member_id")
    private String srcMemberId;

    @JsonProperty("src_member_id")
    public String getSrcMemberId() {
        return srcMemberId;
    }

    @JsonProperty("src_member_id")
    public void setSrcMemberId(String srcMemberId) {
        this.srcMemberId = srcMemberId;
    }

}