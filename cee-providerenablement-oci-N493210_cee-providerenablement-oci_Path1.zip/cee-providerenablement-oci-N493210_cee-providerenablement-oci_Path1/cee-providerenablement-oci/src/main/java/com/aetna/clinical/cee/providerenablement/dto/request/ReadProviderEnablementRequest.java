package com.aetna.clinical.cee.providerenablement.dto.request;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "memberID",
        "memberFirstName",
        "memberLastName",
        "effectiveDate",
        "expirationDate",
        "iaSourceCd"
})

public class ReadProviderEnablementRequest {

    @JsonProperty("memberID")
    private MemberID memberID;
    @JsonProperty("memberFirstName")
    private String memberFirstName;
    @JsonProperty("memberLastName")
    private String memberLastName;
    @JsonProperty("effectiveDate")
    private String effectiveDate;
    @JsonProperty("expirationDate")
    private String expirationDate;
    @JsonProperty("iaSourceCd")
    private String iaSourceCd;

    @JsonProperty("memberID")
    public MemberID getMemberID() {
        return memberID;
    }

    @JsonProperty("memberID")
    public void setMemberID(MemberID memberID) {
        this.memberID = memberID;
    }

    @JsonProperty("memberFirstName")
    public String getMemberFirstName() {
        return memberFirstName;
    }

    @JsonProperty("memberFirstName")
    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
    }

    @JsonProperty("memberLastName")
    public String getMemberLastName() {
        return memberLastName;
    }

    @JsonProperty("memberLastName")
    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
    }

    @JsonProperty("effectiveDate")
    public String getEffectiveDate() {
        return effectiveDate;
    }

    @JsonProperty("effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    @JsonProperty("expirationDate")
    public String getExpirationDate() {
        return expirationDate;
    }

    @JsonProperty("expirationDate")
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    @JsonProperty("iaSourceCd")
    public String getIaSourceCd() {
        return iaSourceCd;
    }

    @JsonProperty("iaSourceCd")
    public void setIaSourceCd(String iaSourceCd) {
        this.iaSourceCd = iaSourceCd;
    }

}