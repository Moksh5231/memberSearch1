package com.aetna.clinical.cee.providerenablement.util;

public class ProviderEnablementConstant{
    public static final String CODE_400 = "400";
    public static final String CODE_400_MESSAGE = "Bad Request";
    public static final String CODE_400_INFO= "Invalid Input";

    public static final String CODE_404 = "404";
    public static final String CODE_404_MESSAGE = "Data Not Found";
    public static final String CODE_404_INFO = "No details found for the proxy/member id";
    
    public static final String CODE_500 = "500";
    public static final String CODE_500_MESSAGE = "Internal Server Error";
    public static final String CODE_500_INFO = "Server Error in Processing the request";
    
    public static final String CODE_500_INFO_ENCRYPTION="Error in Service call - Encryption";

    public static final String CODE_JSON_ERROR_INFO = "Error in Json conversion";
    public static final String AUTHORIZATION = "Authorization";
    public static final String BASIC = "Basic ";
    public static final String BEARER = "Bearer ";
    public static final String TOKEN_SCOPE = "APPPII APPPHI";

    public static final long TOKEN_EXPIRE_TIME = 180;

    public static final String CODE_CROSSWALK_ERROR_INFO =  "Error in Crosswalk Service call";
    public static final String TOKEN_SCOPE_PUBLIC_NONPII ="Public NonPII";
    public static final String TOKEN_SCOPE_APPPII_APPPHI = "APPPII APPPHI";
    public static final String TOKEN_CREDENTIAL = "client_credentials";
    public static final String TRANSACTION_ID = "x-global-transaction-id";
    public static final String EIE_APPLICATION_HEADER = "eieapplication";
    public static final String CEE_APPLICATION_HEADER = "ceeHeader";
    public static final String CEE_APPLICATION = "ceeapplication";
    
    public static final String CROSSWALK_ASOFDATE_FORMAT = "yyyy-MM-dd";
}
