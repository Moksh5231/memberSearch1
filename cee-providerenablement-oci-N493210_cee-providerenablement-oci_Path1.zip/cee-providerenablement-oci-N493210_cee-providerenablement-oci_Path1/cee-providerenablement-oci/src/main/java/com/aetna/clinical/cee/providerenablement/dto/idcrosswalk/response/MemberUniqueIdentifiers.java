package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response;

import java.util.List;

public class MemberUniqueIdentifiers {
	
	private String preferredGlobalID;

    private List<String> alternateGlobalIDs;

    private String linkID;

    private String clinicalPlatformIndicator;

	public String getPreferredGlobalID() {
		return preferredGlobalID;
	}

	public void setPreferredGlobalID(String preferredGlobalID) {
		this.preferredGlobalID = preferredGlobalID;
	}

	public List<String> getAlternateGlobalIDs() {
		return alternateGlobalIDs;
	}

	public void setAlternateGlobalIDs(List<String> alternateGlobalIDs) {
		this.alternateGlobalIDs = alternateGlobalIDs;
	}

	public String getLinkID() {
		return linkID;
	}

	public void setLinkID(String linkID) {
		this.linkID = linkID;
	}

	public String getClinicalPlatformIndicator() {
		return clinicalPlatformIndicator;
	}

	public void setClinicalPlatformIndicator(String clinicalPlatformIndicator) {
		this.clinicalPlatformIndicator = clinicalPlatformIndicator;
	}

}
