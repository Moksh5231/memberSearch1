package com.aetna.clinical.cee.providerenablement.service;

import com.aetna.clinical.cee.providerenablement.dto.memberdelegation.response.MemberDelegationResponseDTO;

public interface MemberDelegationService {

	public MemberDelegationResponseDTO getMemberDelegationDetails(String memberId, String transactionId);
}
