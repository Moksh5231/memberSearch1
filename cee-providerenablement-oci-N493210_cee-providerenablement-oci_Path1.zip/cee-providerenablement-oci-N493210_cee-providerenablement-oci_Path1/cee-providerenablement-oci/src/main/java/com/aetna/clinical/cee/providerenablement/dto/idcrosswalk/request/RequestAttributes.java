package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request;

public class RequestAttributes {
	
	private String searchReqID;

    private String applicationID;

	public String getSearchReqID() {
		return searchReqID;
	}

	public void setSearchReqID(String searchReqID) {
		this.searchReqID = searchReqID;
	}

	public String getApplicationID() {
		return applicationID;
	}

	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}

}
