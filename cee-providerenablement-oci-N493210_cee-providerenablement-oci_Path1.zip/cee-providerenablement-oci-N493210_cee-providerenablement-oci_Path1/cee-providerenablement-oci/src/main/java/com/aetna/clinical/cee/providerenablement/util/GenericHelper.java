package com.aetna.clinical.cee.providerenablement.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Component
public class GenericHelper {

    private String clientId;
    private String clientSecret;
    private String tokenUrl;

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    DataConverter objectConverter;
    @Autowired
    private Environment evi;

    private static Map<String, com.aetna.clinical.cee.providerenablement.util.Token> apicToken = new HashMap<>();

    private static Logger logger = LoggerFactory.getLogger(GenericHelper.class);

    private void setEnvironmentalProperties(String serviceId){
        clientId = evi.getProperty(serviceId + ".apic.clientId");
        clientSecret = evi.getProperty(serviceId + ".apic.clientSecret");
        tokenUrl = evi.getProperty(serviceId + ".apic.tokenUrl");
    }

    public HttpHeaders buildHttpHeader(String serviceId, String scope) {
        HttpHeaders httpHeaders = new HttpHeaders();
        Token apicTokenData = getApicToken(serviceId, scope);
        if (null != apicTokenData) {
            httpHeaders.add(ProviderEnablementConstant.AUTHORIZATION, ProviderEnablementConstant.BEARER + apicTokenData.getAccess_token());
        }
        return httpHeaders;
    }

    public static void setApicToken(String serviceId, Token apicToken) {
        GenericHelper.apicToken.put(serviceId,apicToken);
    }

    public Token getApicToken(String serviceId, String scope) {
        if (null == apicToken.get(serviceId) || isApicTokenExpired(serviceId)) {
            setEnvironmentalProperties(serviceId);
            setApicToken(serviceId,getFreshApicToken(serviceId, scope));
        }
        return apicToken.get(serviceId);
    }

    private Token getFreshApicToken(String serviceId, String scope) {
        Token apicTokenData = null;
        try {
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("grant_type", ProviderEnablementConstant.TOKEN_CREDENTIAL);
            map.add("client_id", clientId);
            map.add("client_secret", clientSecret);
            map.add("scope", scope);
//            logger.info("scope for token - {}", scope);
//            logger.info("APIC token call start - {} Token url -  {}", serviceId, tokenUrl);
            ResponseEntity<String> postResponse = restTemplate.postForEntity(tokenUrl, map, String.class);

            String responseBody = postResponse.getBody();
//            logger.info("APIC token call success - responseBody - {}", responseBody);
            apicTokenData = (Token) objectConverter.jsonToObject(responseBody, Token.class);
            setApicToken(serviceId, apicTokenData);
            String apicTokenStr = objectConverter.convertToJson(apicTokenData);
//            logger.info("{} apic token {}", serviceId, apicTokenStr);
            apicTokenData.setExpires_in(apicTokenData.getExpires_in());
//            logger.info("{} apic Token value - {}", serviceId, apicTokenData.getAccess_token());
//            logger.info("{} apic  Token Information : Token created Expiration Time - {} in seconds" , serviceId, apicTokenData.getExpires_in());
        } catch (Exception tokenException) {
            logger.error("Exception occured while creating token-{}",tokenException.getMessage());
        }
        return apicTokenData;
    }

    public boolean isApicTokenExpired(String serviceId) {
        Token apicTokenData = apicToken.get(serviceId);
        boolean tokenExpired = true;
        Instant instant = Instant.now();
        long timeStampSeconds = instant.getEpochSecond();
//        logger.info("token expire time {} in seconds", apicTokenData.getExpires_in());
//        logger.info("token created time - {} , current time - {}", apicTokenData.getConsented_on(), timeStampSeconds);
        long timeInterval = timeStampSeconds - apicTokenData.getConsented_on();
//        logger.info("timeInterval in sec {}", timeInterval);
        if (timeInterval < apicTokenData.getExpires_in()) {
//            logger.info("token not expired");
            tokenExpired = false;
        } else {
//            logger.info("token expired");
        }
        return tokenExpired;
    }
}
