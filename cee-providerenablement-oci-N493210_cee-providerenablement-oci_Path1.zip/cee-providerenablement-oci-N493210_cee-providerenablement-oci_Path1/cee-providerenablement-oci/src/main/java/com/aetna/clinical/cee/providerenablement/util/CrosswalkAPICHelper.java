package com.aetna.clinical.cee.providerenablement.util;

import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.aetna.clinical.cee.providerenablement.exception.ProviderEnablementException;

@Service
public class CrosswalkAPICHelper {
	
	@Value("${crosswalk.apic.clientId}")
	private String crosswalkClientId;
	
	@Value("${crosswalk.apic.clientSecret}")
	private String crosswalkClientSecret;
	
	@Value("${crosswalk.apic.tokenUrl}")
	private String crosswalkTokenUrl;
	
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	private DataConverter objectConverter;
	
	private static volatile Token crosswalkApicToken = null;
	
	private static Logger logger = LoggerFactory.getLogger(CrosswalkAPICHelper.class);
	
	/**
	 * This method gets the latest application token and application client_id and sets in HttpHeaders.
	 * @return
	 */
	public HttpHeaders buildCrosswalkHttpHeader(){		
		HttpHeaders httpHeaders = new HttpHeaders();	
		Token apicToken = getCrosswalkApicToken();
		if(null != apicToken){
			httpHeaders.add(ProviderEnablementConstant.AUTHORIZATION, ProviderEnablementConstant.BEARER +apicToken.getAccess_token());
		}			
		//httpHeaders.add("X-IBM-Client-Id", crosswalkClientId);		
		return httpHeaders;
	}
	
	public Token getCrosswalkApicToken(){
		 /*
		 * Double checking object state inside synchronized block to avoid duplicate object creation in threading.
		 */
		if(null == crosswalkApicToken || isCrosswalkApicTokenExpired()){
			crosswalkApicToken = getFreshCrosswalkApicToken();
			/*synchronized(CrosswalkAPICHelper.class){
				if(null == crosswalkApicToken || isCrosswalkApicTokenExpired()){
					crosswalkApicToken = getFreshCrosswalkApicToken();		
				}
			}*/
		}
		return crosswalkApicToken;
	}
	
	private Token getFreshCrosswalkApicToken(){
		try
		{			
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();		
			map.add("grant_type", ProviderEnablementConstant.TOKEN_CREDENTIAL);
			map.add("client_id", crosswalkClientId);
			map.add("client_secret", crosswalkClientSecret);
			map.add("scope", ProviderEnablementConstant.TOKEN_SCOPE);		
			logger.info("scope for token - {}",ProviderEnablementConstant.TOKEN_SCOPE);
			//HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(map, httpHeaders);
			logger.info("APIC token call start - Crosswalk Token url -  {}", crosswalkTokenUrl);
			ResponseEntity<String> postResponse = restTemplate.postForEntity(crosswalkTokenUrl, map, String.class);		
			
			
			String responseBody = postResponse.getBody();
			logger.info("APIC token call success - responseBody - {}",responseBody);
			crosswalkApicToken = (Token) objectConverter.jsonToObject(responseBody, Token.class);    
			logger.info("crosswalk apic token {}",objectConverter.convertToJson(crosswalkApicToken));
			crosswalkApicToken.setExpires_in(crosswalkApicToken.getExpires_in());
			logger.info("crosswalk apic Token value - {}",crosswalkApicToken.getAccess_token());
			logger.info("crosswalk apic  Token Information : Token created Expiration Time - {} in seconds"+crosswalkApicToken.getExpires_in());
			
		}catch(Exception tokenException){
			logger.error("Exception in getApplicationToken {}", tokenException);
			throw new ProviderEnablementException(ProviderEnablementConstant.CODE_500, ProviderEnablementConstant.CODE_500_MESSAGE, tokenException.getMessage());
		}
		return crosswalkApicToken;
	}
	
	
	public boolean isCrosswalkApicTokenExpired(){
		boolean tokenExpired = true;
		Instant instant = Instant.now();
		long timeStampSeconds = instant.getEpochSecond();
		logger.info("token expire time {} in seconds",crosswalkApicToken.getExpires_in());
		logger.info("token created time - {} , current time - {}", crosswalkApicToken.getConsented_on(),timeStampSeconds);
		long timeInterval = timeStampSeconds - crosswalkApicToken.getConsented_on();
		logger.info("timeInterval in sec {}", timeInterval);
		if(timeInterval < crosswalkApicToken.getExpires_in()) {
			logger.info("token not expired");
			tokenExpired = false;
		}else {
			logger.info("token expired"); 
			
		}
		return tokenExpired;
		
	}


}
