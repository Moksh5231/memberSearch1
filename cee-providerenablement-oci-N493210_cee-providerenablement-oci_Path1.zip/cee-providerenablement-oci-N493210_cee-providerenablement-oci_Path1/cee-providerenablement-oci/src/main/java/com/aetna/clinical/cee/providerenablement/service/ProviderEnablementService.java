package com.aetna.clinical.cee.providerenablement.service;

public interface ProviderEnablementService {
}
