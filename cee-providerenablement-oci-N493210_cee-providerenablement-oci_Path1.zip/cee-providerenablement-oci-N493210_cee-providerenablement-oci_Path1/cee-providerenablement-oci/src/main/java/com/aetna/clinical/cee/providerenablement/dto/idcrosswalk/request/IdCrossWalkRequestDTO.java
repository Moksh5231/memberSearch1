package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request;

public class IdCrossWalkRequestDTO {
	private IdCrossWalkSearchRequest idCrossWalkSearchRequest;

	public IdCrossWalkSearchRequest getIdCrossWalkSearchRequest() {
		return idCrossWalkSearchRequest;
	}

	public void setIdCrossWalkSearchRequest(IdCrossWalkSearchRequest idCrossWalkSearchRequest) {
		this.idCrossWalkSearchRequest = idCrossWalkSearchRequest;
	}

}
