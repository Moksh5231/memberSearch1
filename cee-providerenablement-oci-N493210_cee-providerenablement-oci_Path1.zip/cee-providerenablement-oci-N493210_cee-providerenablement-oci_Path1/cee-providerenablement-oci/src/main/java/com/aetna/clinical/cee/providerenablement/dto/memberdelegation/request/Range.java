package com.aetna.clinical.cee.providerenablement.dto.memberdelegation.request;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "effectivedate"
})
@Generated("jsonschema2pojo")
public class Range {

    @JsonProperty("effectivedate")
    private Effectivedate effectivedate;

    @JsonProperty("effectivedate")
    public Effectivedate getEffectivedate() {
        return effectivedate;
    }

    @JsonProperty("effectivedate")
    public void setEffectivedate(Effectivedate effectivedate) {
        this.effectivedate = effectivedate;
    }

}