package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response;

import java.util.List;

public class MemberSourceRecords {

	private List<SourceSystemIdTypes> sourceSystemIdTypes;

    private String sourceSystemQualifier;

    private String ssklastUpdatedTime;
    
    public List<SourceSystemIdTypes> getSourceSystemIdTypes() {
		return sourceSystemIdTypes;
	}

	public void setSourceSystemIdTypes(List<SourceSystemIdTypes> sourceSystemIdTypes) {
		this.sourceSystemIdTypes = sourceSystemIdTypes;
	}

	public String getSourceSystemQualifier() {
		return sourceSystemQualifier;
	}

	public void setSourceSystemQualifier(String sourceSystemQualifier) {
		this.sourceSystemQualifier = sourceSystemQualifier;
	}

	public String getSsklastUpdatedTime() {
		return ssklastUpdatedTime;
	}

	public void setSsklastUpdatedTime(String ssklastUpdatedTime) {
		this.ssklastUpdatedTime = ssklastUpdatedTime;
	}
}
