/*
 * Created Dec 2007
 * Updated May 2009
 * Updated Mar 2010 (Java 5 code improvements)
 */
package com.aetna.clinical.cee.common.exceptions;

/**
 * <code>EntityAlreadyExistsException</code> is an unchecked exception that describes the technical
 * and business errors that occur during the persistence of a new object instance when an object
 * of the same type has already been persisted with the same identifying information.  Note
 * that it's packaged with common code, which is intended to imply a lack of
 * dependency on other packages as well as its reusable nature (within various subsystems of the
 * application).
 * <p>
 * Note: The Spring Framework and various persistence frameworks offer their own persistence exception
 * hierarchies.  This class was created in support of stub DAO implementations.
 * <p>
 * Note: This class exists as an example of how to package and deploy such components and is not
 * considered reusable across the enterprise (and thus not supported), although any application is
 * free to leverage this code.
 * 
 * @author Kent Rancourt
 * @author Tony Kerz
 */
public class EntityAlreadyExistsException extends AbstractEntityException {

    private static final long serialVersionUID = 6403540322271232314L;

    /**
     * Constructor specifying the <code>Class</code> and <code>Integer</code> identifier of
     * the problematic domain object.
     * 
     * @param type the <code>Class</code> of the problematic domain object
     * @param id the <code>Integer</code> identifier of the problematic domain object
     */
    public EntityAlreadyExistsException(Class <?> type, Integer id) {
        super(type, id);
    }
    
}
