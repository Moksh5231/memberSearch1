package com.aetna.clinical.cee.providerenablement.dto.memberdelegation.response;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "typecode",
        "name"
})
@Generated("jsonschema2pojo")
public class Arrangementdetails {

    @JsonProperty("typecode")
    private String typecode;
    @JsonProperty("name")
    private String name;

    @JsonProperty("typecode")
    public String getTypecode() {
        return typecode;
    }

    @JsonProperty("typecode")
    public void setTypecode(String typecode) {
        this.typecode = typecode;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

}