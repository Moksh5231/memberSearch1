package com.aetna.clinical.cee.providerenablement.util;

public class Token {
    String token_type, access_token, scope;
    long expires_in,consented_on;
    public String getToken_type() {
        return token_type;
    }
    public void setToken_type(String token_type) {
        this.token_type = token_type;
    }
    public String getAccess_token() {
        return access_token;
    }
    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }
    public String getScope() {
        return scope;
    }
    public void setScope(String scope) {
        this.scope = scope;
    }
    public long getExpires_in() {
        return expires_in;
    }
    public void setExpires_in(long expires_in) {
        this.expires_in = expires_in;
    }
    public long getConsented_on() {
        return consented_on;
    }
    public void setConsented_on(long consented_on) {
        this.consented_on = consented_on;
    }
}
