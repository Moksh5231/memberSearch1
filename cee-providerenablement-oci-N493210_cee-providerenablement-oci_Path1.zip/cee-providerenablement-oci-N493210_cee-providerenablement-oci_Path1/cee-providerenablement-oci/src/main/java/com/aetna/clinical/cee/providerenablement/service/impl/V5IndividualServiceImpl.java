package com.aetna.clinical.cee.providerenablement.service.impl;

/*import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.request.IdXWalkRequestDTO;
import com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response.IdXWalkResponseDTO;
import com.aetna.clinical.cee.providerenablement.exception.ProviderEnablementException;
import com.aetna.clinical.cee.providerenablement.service.MemberDelegationService;
import com.aetna.clinical.cee.providerenablement.service.V5IndividualService;
import com.aetna.clinical.cee.providerenablement.util.DataConverter;
import com.aetna.clinical.cee.providerenablement.util.GenericHelper;
import com.aetna.clinical.cee.providerenablement.util.ProviderEnablementConstant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
*/
import org.springframework.stereotype.Service;


@Service
public class V5IndividualServiceImpl //implements V5IndividualService
{
    /*final String CLASS_NAME = "V5IndividualServiceImpl";
    final String SERVICE_ID = "v5individuals";

    private static final Logger logger = LoggerFactory.getLogger(V5IndividualServiceImpl.class);

    @Autowired
    RestTemplate restTemplate;

    @Value("${v5individuals.apic.url}")
    private String idXwalkServiceApicUrl;

    @Autowired
    private GenericHelper idXwalkServiceAPICHelper;

    @Autowired
    DataConverter objectConverter;




    @Override
    public IdXWalkResponseDTO getMemberIdCrossWalk(IdXWalkRequestDTO idXWalkRequest, String transactionId) throws ProviderEnablementException {
        final String METHOD_NAME="getMemberIdCrossWalk";

        IdXWalkResponseDTO idXWalkResponse = null;

        int statusCode;
        StopWatch time=new StopWatch();
        try {

            logger.info(" METHOD_NAME={}, transactionId={}, message=\"REQUEST\", information={}",METHOD_NAME,transactionId,objectConverter.convertToJson(idXWalkRequest));
            //        APIC call
            HttpHeaders httpHeaders = idXwalkServiceAPICHelper.buildHttpHeader(SERVICE_ID, ProviderEnablementConstant.TOKEN_SCOPE_APPPII_APPPHI);
            HttpEntity<Object> httpEntity = new HttpEntity<>(null, httpHeaders);
//        buildUrl call

            String idXwalkUrl = buildUrl(idXWalkRequest);
            logger.info(" METHOD_NAME={}, transactionId={}, message=\"URL_INFO\", information={}",METHOD_NAME,transactionId,idXwalkUrl);
            ResponseEntity<String> result = null;
            time.start();
            result = restTemplate.exchange(idXwalkUrl, HttpMethod.GET, httpEntity, String.class);
            time.stop();
            if (null != result) {
                statusCode = result.getStatusCodeValue();
                logger.info(" METHOD_NAME={}, transactionId={}, message={}, information={}, ResponseTime={}ms",METHOD_NAME,transactionId,statusCode,time.getTotalTimeMillis());
                if (statusCode == 200) {
                    idXWalkResponse = (IdXWalkResponseDTO) objectConverter.jsonToObjectWithUnknownProperties(result.getBody(), IdXWalkResponseDTO.class);
                    logger.info(" METHOD_NAME={}, transactionId={}, message={}, information={}",METHOD_NAME,transactionId,result.getBody());
                }
            }
        }catch (HttpStatusCodeException statusException){
            time.stop();
            logger.info(" METHOD_NAME={},transactionId={}, message=\"RESP_STATUS_CODE\", information={}, ResponseTime={}ms",CLASS_NAME,METHOD_NAME,transactionId,statusException.getStatusCode(),time.getTotalTimeMillis());
            ProviderEnablementException providerEnablementException=new ProviderEnablementException("500","Internal Server Error",statusException.getResponseBodyAsString(),METHOD_NAME,CLASS_NAME);
            providerEnablementException.setStackTrace(statusException.getStackTrace());
            throw providerEnablementException;
        }catch (ProviderEnablementException providerEnablementException){
            throw new ProviderEnablementException(providerEnablementException.getCode(),providerEnablementException.getMessage(),providerEnablementException.getMoreInformation(),METHOD_NAME,CLASS_NAME);
        } catch (Exception e){
            ProviderEnablementException providerEnablementException=new ProviderEnablementException("500","Internal Server Error",e.getMessage(),METHOD_NAME,CLASS_NAME);
            providerEnablementException.setStackTrace(e.getStackTrace());
            throw providerEnablementException;
        }

        return idXWalkResponse;

    }

    //    build url method
    private String buildUrl(IdXWalkRequestDTO idXWalkRequest) {

        return idXwalkServiceApicUrl + "?"+getInputValues(idXWalkRequest);

    }

    private String getInputValues(IdXWalkRequestDTO idXWalkRequest) {
        // Expand this method to add Request Parameters
        return "";//return proper value
    }
*/

}