package com.aetna.clinical.cee.providerenablement.exception;

public class ProviderEnablementException extends RuntimeException{
    private String code;
    private String message;
    private String moreInformation;
    private String methodName;
    private String className;

    public ProviderEnablementException(){}

    public ProviderEnablementException(String simpleMessage){
        super(simpleMessage);
    }

    public ProviderEnablementException(Exception e) {
        super(e);
    }

    public ProviderEnablementException(String code, String message, String moreInformation) {
        super(code + " " + message);
        this.code = code;
        this.message = message;
        this.moreInformation = moreInformation;
    }

    public ProviderEnablementException(String code, String message, String moreInformation, String methodName, String className) {
        super(code + " " + message);
        this.code = code;
        this.message = message;
        this.moreInformation = moreInformation;
        this.methodName = methodName;
        this.className = className;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMoreInformation() {
        return moreInformation;
    }

    public void setmoreInformation(String moreInformation) {
        this.moreInformation = moreInformation;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
}
