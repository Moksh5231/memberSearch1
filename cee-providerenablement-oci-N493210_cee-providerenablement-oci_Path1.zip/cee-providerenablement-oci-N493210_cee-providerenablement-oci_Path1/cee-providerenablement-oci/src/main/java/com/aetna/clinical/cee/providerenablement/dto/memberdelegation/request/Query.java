package com.aetna.clinical.cee.providerenablement.dto.memberdelegation.request;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "bool"
})
@Generated("jsonschema2pojo")
public class Query {

    @JsonProperty("bool")
    private Bool bool;

    @JsonProperty("bool")
    public Bool getBool() {
        return bool;
    }

    @JsonProperty("bool")
    public void setBool(Bool bool) {
        this.bool = bool;
    }

}