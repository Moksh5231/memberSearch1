package com.aetna.clinical.cee.providerenablement.util;

import java.security.spec.KeySpec;
import java.util.Base64;

import javax.annotation.PostConstruct;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.aetna.clinical.cee.providerenablement.exception.ProviderEnablementException;

@Service
public class EncryptionService {

	private static final Logger logger = LoggerFactory.getLogger(EncryptionService.class);
	private static String salt = "cee-salt";
	private SecretKeySpec secretKeySpec;
	private byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	private IvParameterSpec ivspec = new IvParameterSpec(iv);

	@Value("${EncryptionVariables.secretKey}")
	public String secretKey;

	@PostConstruct
	public void setKey() {
		try {
			logger.info("setKey Started");
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			secretKeySpec = new SecretKeySpec(tmp.getEncoded(), "AES");
			logger.info("setKey Finish");
		} catch (Exception e) {
			logger.error("Exception Occured in setting SecretKeySpec: " + e.getMessage());
		}

	}

	public String encrypt(String strToEncrypt, String secretKey) {
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivspec);
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
		} catch (Exception e) {
			logger.error("Error In encrypting Sting: " + strToEncrypt + " Error is: " + e.getMessage());
			throw new ProviderEnablementException(ProviderEnablementConstant.CODE_500, ProviderEnablementConstant.CODE_500_MESSAGE, ProviderEnablementConstant.CODE_500_INFO_ENCRYPTION);
		}
		//return null;
	}

	public String decrypt(String strToDecrypt, String secretKey) {
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivspec);
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
		} catch (Exception e) {
			logger.error("Error In decrypting Sting: " + strToDecrypt + " Error is: " + e.getMessage());
		}
		return null;
	}

	public String encrypt(String data) {
		return this.encrypt(data, secretKey);
	}

	public String decrypt(String data) {
		return this.decrypt(data, secretKey);
	}

}
