package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response;

public class IdCrossWalkSearchStatus {
	
	private String statusMessage;

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

}
