package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response;

public class IdCrossWalkSearchResponse {
	
	private IdCrossWalkSearchStatus idCrossWalkSearchStatus;

    private RequestAttributes requestAttributes;

    private MatchedMemberRecords matchedMemberRecords;

	public IdCrossWalkSearchStatus getIdCrossWalkSearchStatus() {
		return idCrossWalkSearchStatus;
	}

	public void setIdCrossWalkSearchStatus(IdCrossWalkSearchStatus idCrossWalkSearchStatus) {
		this.idCrossWalkSearchStatus = idCrossWalkSearchStatus;
	}

	public RequestAttributes getRequestAttributes() {
		return requestAttributes;
	}

	public void setRequestAttributes(RequestAttributes requestAttributes) {
		this.requestAttributes = requestAttributes;
	}

	public MatchedMemberRecords getMatchedMemberRecords() {
		return matchedMemberRecords;
	}

	public void setMatchedMemberRecords(MatchedMemberRecords matchedMemberRecords) {
		this.matchedMemberRecords = matchedMemberRecords;
	}


}
