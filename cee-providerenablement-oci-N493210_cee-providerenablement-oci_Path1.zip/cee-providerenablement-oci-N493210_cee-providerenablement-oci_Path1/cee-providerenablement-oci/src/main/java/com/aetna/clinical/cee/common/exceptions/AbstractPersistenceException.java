/*
 * Created Dec 2007
 * Updated May 2009
 * Updated Mar 2010 (Java 5 code improvements)
 */
package com.aetna.clinical.cee.common.exceptions;

/**
 * <code>AbstractPersistenceException</code> is a base class for unchecked exceptions that describe
 * any persistence problem.
 * <p>
 * Note: The Spring Framework and various persistence frameworks offer their own persistence
 * exception hierarchies.  This class was created in support of stub DAO implementations.  
 * <p>
 * Note: This class exists as an example of how to package and deploy such components and is not
 * considered reusable across the enterprise (and thus not supported), although any application is
 * free to leverage this code.
 * 
 * @author Kent Rancourt
 * @author Tony Kerz
 */
public abstract class AbstractPersistenceException extends RuntimeException {
    
	private static final long serialVersionUID = 4716913405950982988L;

	public AbstractPersistenceException(String message) {
        super(message);
    }
    
}
