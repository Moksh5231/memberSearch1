package com.aetna.clinical.cee.providerenablement.dto.response;

import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "orgdetails",
        "arrangementdetails",
        "iappltngrpid",
        "folder",
        "dealtypecd",
        "populationname",
        "effectivedate",
        "memberdetails",
        "expirationdate",
        "iasourcecd",
        "delegationstatus"
})
@Generated("jsonschema2pojo")
public class MemberProviderDelegation {

    @JsonProperty("orgdetails")
    private Orgdetails orgdetails;
    @JsonProperty("arrangementdetails")
    private Arrangementdetails arrangementdetails;
    @JsonProperty("iappltngrpid")
    private String iappltngrpid;
    @JsonProperty("folder")
    private String folder;
    @JsonProperty("dealtypecd")
    private String dealtypecd;
    @JsonProperty("populationname")
    private String populationname;
    @JsonProperty("effectivedate")
    private String effectivedate;
    @JsonProperty("memberdetails")
    private Memberdetails memberdetails;
    @JsonProperty("expirationdate")
    private String expirationdate;
    @JsonProperty("iasourcecd")
    private String iasourcecd;
    @JsonProperty("delegationstatus")
    private String delegationstatus;

    @JsonProperty("orgdetails")
    public Orgdetails getOrgdetails() {
        return orgdetails;
    }

    @JsonProperty("orgdetails")
    public void setOrgdetails(Orgdetails orgdetails) {
        this.orgdetails = orgdetails;
    }

    @JsonProperty("arrangementdetails")
    public Arrangementdetails getArrangementdetails() {
        return arrangementdetails;
    }

    @JsonProperty("arrangementdetails")
    public void setArrangementdetails(Arrangementdetails arrangementdetails) {
        this.arrangementdetails = arrangementdetails;
    }

    @JsonProperty("iappltngrpid")
    public String getIappltngrpid() {
        return iappltngrpid;
    }

    @JsonProperty("iappltngrpid")
    public void setIappltngrpid(String iappltngrpid) {
        this.iappltngrpid = iappltngrpid;
    }

    @JsonProperty("folder")
    public String getFolder() {
        return folder;
    }

    @JsonProperty("folder")
    public void setFolder(String folder) {
        this.folder = folder;
    }

    @JsonProperty("dealtypecd")
    public String getDealtypecd() {
        return dealtypecd;
    }

    @JsonProperty("dealtypecd")
    public void setDealtypecd(String dealtypecd) {
        this.dealtypecd = dealtypecd;
    }

    @JsonProperty("populationname")
    public String getPopulationname() {
        return populationname;
    }

    @JsonProperty("populationname")
    public void setPopulationname(String populationname) {
        this.populationname = populationname;
    }

    @JsonProperty("effectivedate")
    public String getEffectivedate() {
        return effectivedate;
    }

    @JsonProperty("effectivedate")
    public void setEffectivedate(String effectivedate) {
        this.effectivedate = effectivedate;
    }

    @JsonProperty("memberdetails")
    public Memberdetails getMemberdetails() {
        return memberdetails;
    }

    @JsonProperty("memberdetails")
    public void setMemberdetails(Memberdetails memberdetails) {
        this.memberdetails = memberdetails;
    }

    @JsonProperty("expirationdate")
    public String getExpirationdate() {
        return expirationdate;
    }

    @JsonProperty("expirationdate")
    public void setExpirationdate(String expirationdate) {
        this.expirationdate = expirationdate;
    }

    @JsonProperty("iasourcecd")
    public String getIasourcecd() {
        return iasourcecd;
    }

    @JsonProperty("iasourcecd")
    public void setIasourcecd(String iasourcecd) {
        this.iasourcecd = iasourcecd;
    }

    @JsonProperty("delegationstatus")
    public String getDelegationstatus() {
        return delegationstatus;
    }

    @JsonProperty("delegationstatus")
    public void setDelegationstatus(String delegationstatus) {
        this.delegationstatus = delegationstatus;
    }

}