package com.aetna.clinical.cee.providerenablement.util;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class LoggerAsyncService {
	
	private static Logger logger = LoggerFactory.getLogger(LoggerAsyncService.class);

	@Autowired
	EncryptionService encService;
	
	@Async("asyncLogExecutor")
	public void logControllerStatements(Logger log, String response,  String encryptedProxyId,String transactionId, StopWatch responseTimer) {
		String encryptedResponse = null;
		try {
			encryptedResponse = encService.encrypt(response);
			/*
			System.out.println("encryptedResponse===========>"+encryptedResponse);			
			Thread.sleep(5000);
			System.out.println("Thread sleep completed=================================");
			*/
			log.info("Appointments response for proxy id - [{}], Transaction Id - {}, ResponseTime - {} ms, response - {}", encryptedProxyId,transactionId, responseTimer.getTime(TimeUnit.MILLISECONDS),encryptedResponse);
		}catch(Exception genericException) {
			logger.error("GenericException in logControllerStatements for Transaction Id - {}, error message {} >>>" ,transactionId,genericException.getMessage());
			
		}
		
	}
	
	@Async("asyncLogExecutor")
	public void logServiceStatements(String msg, Logger log,  String transactionId, StopWatch responseTimer, String response) {
		String encryptedResponse = null;
		try {
			encryptedResponse = encService.encrypt(response);
			/*
			System.out.println("encryptedResponse===========>"+encryptedResponse);			
			Thread.sleep(5000);
			System.out.println("Thread sleep completed=================================");
			*/
			log.info(msg, transactionId, responseTimer.getTime(TimeUnit.MILLISECONDS),encryptedResponse);
		}catch(Exception genericException) {
			logger.error("GenericException in logServiceStatements for Transaction Id - {}, error message {} >>>" ,transactionId,genericException.getMessage());
			
		}
		
	}	
	
	
	@Async("asyncLogExecutor")
	public void logService(String msg, Logger log, String transactionId, String value) {
		String encryptedValue = null;
		try {
			encryptedValue = encService.encrypt(value);
			log.info(msg, transactionId,encryptedValue);
		}catch(Exception genericException) {
			logger.error("GenericException in logService for Transaction Id - {}, error message {} >>>" ,transactionId,genericException.getMessage());
			
		}
		
	}
	
	@Async("asyncLogExecutor")
	public void logController(String msg, Logger log, String encryptedProxyId, String transactionId, String value) {
		String encryptedValue = null;
		try {
			encryptedValue = encService.encrypt(value);
			log.info(msg, encryptedProxyId,transactionId,encryptedValue);
		}catch(Exception genericException) {
			logger.error("GenericException in logService for Transaction Id - {}, error message {} >>>" ,transactionId,genericException.getMessage());
			
		}
		
	}	


}
