/*
 * Created Dec 2007
 * Update May 2009
 * Updated Mar 2010 (Java 5 code improvements)
 */
package com.aetna.clinical.cee.common.exceptions;

/**
 * <code>EntityNotFoundException</code> is an unchecked exception that describes the technical
 * and business errors that occur when a persistent object that is expected to be found is not.  This
 * would typically occur during an update or delete operation since retrieval operation should not
 * assume any results will be found (as in the case of a search that returns nothing).  Note
 * that it's packaged with common code, which is intended to imply a lack of
 * dependency on other packages as well as its reusable nature (within various subsystems of the
 * application).
 * <p>
 * Note: The Spring Framework and various persistence frameworks offer their own persistence exception
 * hierarchies.  This class was created in support for stub DAO implementations.
 * <p>
 * Note: This class exists as an example of how to package and deploy such components and is not
 * considered reusable across the enterprise (and thus not supported), although any application is
 * free to leverage this code.
 * 
 * @author Kent Rancourt
 * @author Tony Kerz
 */
public class EntityNotFoundException extends AbstractEntityException {

    private static final long serialVersionUID = 3557715799094036436L;

    /**
     * Constructor specifying the <code>Class</code> and <code>Integer</code> identifier of
     * the problematic domain object.
     * 
     * @param type the <code>Class</code> of the problematic domain object
     * @param id the <code>Integer</code> identifier of the problematic domain object
     */
    public EntityNotFoundException(Class <?> type, Integer id) {
        super(type, id);
    }
    
}
