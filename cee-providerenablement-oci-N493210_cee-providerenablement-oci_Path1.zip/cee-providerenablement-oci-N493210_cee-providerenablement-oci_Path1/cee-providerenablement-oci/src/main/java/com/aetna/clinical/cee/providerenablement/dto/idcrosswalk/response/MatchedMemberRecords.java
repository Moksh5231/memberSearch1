package com.aetna.clinical.cee.providerenablement.dto.idcrosswalk.response;

import java.util.List;

public class MatchedMemberRecords {

	private MemberUniqueIdentifiers memberUniqueIdentifiers;

    private List<MemberSourceRecords> memberSourceRecords;

	public MemberUniqueIdentifiers getMemberUniqueIdentifiers() {
		return memberUniqueIdentifiers;
	}

	public void setMemberUniqueIdentifiers(MemberUniqueIdentifiers memberUniqueIdentifiers) {
		this.memberUniqueIdentifiers = memberUniqueIdentifiers;
	}

	public List<MemberSourceRecords> getMemberSourceRecords() {
		return memberSourceRecords;
	}

	public void setMemberSourceRecords(List<MemberSourceRecords> memberSourceRecords) {
		this.memberSourceRecords = memberSourceRecords;
	}


}
