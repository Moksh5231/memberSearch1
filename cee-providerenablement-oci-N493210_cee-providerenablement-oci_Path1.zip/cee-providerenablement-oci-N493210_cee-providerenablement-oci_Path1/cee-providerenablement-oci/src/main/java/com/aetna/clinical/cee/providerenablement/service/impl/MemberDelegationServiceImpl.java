package com.aetna.clinical.cee.providerenablement.service.impl;

import com.aetna.clinical.cee.providerenablement.dto.memberdelegation.request.MemberDelegationRequestDTO;
import com.aetna.clinical.cee.providerenablement.dto.memberdelegation.response.MemberDelegationResponseDTO;
import com.aetna.clinical.cee.providerenablement.exception.ProviderEnablementException;
import com.aetna.clinical.cee.providerenablement.service.MemberDelegationService;
import com.aetna.clinical.cee.providerenablement.util.DataConverter;
import com.aetna.clinical.cee.providerenablement.util.GenericHelper;
import com.aetna.clinical.cee.providerenablement.util.ProviderEnablementConstant;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

@Service
public class MemberDelegationServiceImpl implements MemberDelegationService {

    static final String CLASS_NAME="MemberDelegationServiceImpl";
    static final String SERVICE_ID="memberdelegation";
    private static Logger logger= LoggerFactory.getLogger(MemberDelegationServiceImpl.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private DataConverter objectConverter;

    @Autowired
    private GenericHelper memberDelegationAPICHelper;

    @Value("${memberdeligation.apic.url}")
    private String memberdelegationServiceApicUrl;

    @Override
    public MemberDelegationResponseDTO getMemberDelegationDetails(String memberId, String transactionId) {
        final String METHOD_NAME="getMemberDelegation";
        int statusCode;
        MemberDelegationResponseDTO memberDelegationResponse = new MemberDelegationResponseDTO();
        StopWatch time = new StopWatch();
        // Prearing Headers
        try{
       
        MemberDelegationRequestDTO request = createMemberDelegatioRequest(memberId,transactionId);
        HttpHeaders httpHeaders = memberDelegationAPICHelper.buildHttpHeader(SERVICE_ID, ProviderEnablementConstant.TOKEN_SCOPE_APPPII_APPPHI);
        HttpEntity<Object> httpEntity = new HttpEntity<>(null, httpHeaders);
        ResponseEntity<String> response = null;
        //build URL
       
        logger.info(" METHOD_NAME={}, transactionId={}, message=\"URL_INFO\", information={}",METHOD_NAME,transactionId,memberdelegationServiceApicUrl);

      
//      calling the API
        time.start();
        response = restTemplate.postForEntity(memberdelegationServiceApicUrl, httpEntity, String.class);
        time.stop();

        statusCode = (null!=response?response.getStatusCodeValue():-1);
        logger.info(" METHOD_NAME={}, transactionId={}, message=\"RESP_STATUS_CODE\", information={}, ResponseTime={}ms",  METHOD_NAME, transactionId, statusCode, time.getTotalTimeMillis());

        if (statusCode == 200) {
            memberDelegationResponse = (MemberDelegationResponseDTO) objectConverter.jsonToObjectWithUnknownProperties(response.getBody(), MemberDelegationResponseDTO.class);

            logger.info(" METHOD_NAME={},transactionId={}, message=\"SUCCESS_RESPONSE\", information={}",  METHOD_NAME, transactionId, objectConverter.convertToJson(memberDelegationResponse));

        }

    }catch (HttpStatusCodeException statusException){
        time.stop();
        logger.info(" METHOD_NAME={},transactionId={}, message=\"RESP_STATUS_CODE\", information={}, ResponseTime={}ms",CLASS_NAME,METHOD_NAME,transactionId,statusException.getStatusCode(),time.getTotalTimeMillis());
        ProviderEnablementException providerEnablementException=new ProviderEnablementException("500","Internal Server Error",statusException.getResponseBodyAsString(),METHOD_NAME,CLASS_NAME);
            providerEnablementException.setStackTrace(statusException.getStackTrace());
        throw providerEnablementException;
    }catch (ProviderEnablementException providerEnablementException){
        throw new ProviderEnablementException(providerEnablementException.getCode(),providerEnablementException.getMessage(),providerEnablementException.getMoreInformation(),METHOD_NAME,CLASS_NAME);
    } catch (Exception e){
            ProviderEnablementException providerEnablementException=new ProviderEnablementException("500","Internal Server Error",e.getMessage(),METHOD_NAME,CLASS_NAME);
            providerEnablementException.setStackTrace(e.getStackTrace());
        throw providerEnablementException;
    }



        return memberDelegationResponse;
    }




    public MemberDelegationRequestDTO createMemberDelegatioRequest(String memberId, String transactionId) {
        MemberDelegationRequestDTO request = new MemberDelegationRequestDTO();

        // Need to implement complete method
        return request;
    }










    }
