package com.aetna.clinical.cee.spring.boot;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

@ImportResource({ "classpath*:/app-context/**/*.xml", })
@ComponentScan({ "com.aetna.clinical.cee", "com.aetna.framework.diagnostic" })
//@EnableJpaRepositories(basePackages = "com.aetna.clinical.cee.repositories")
//@EntityScan(basePackages = { "com.aetna.clinical.cee.entity", "com.aetna.clinical.cee.entities" })
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class SpringBootStarter extends SpringBootServletInitializer {
	static Logger logger = LoggerFactory.getLogger(SpringBootStarter.class);

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		logger.info("SpringBootStarter - configure");

		return application.sources(SpringBootStarter.class);
	}

	public static void main(String[] args) {
		logger.info("SpringBootStarter - main");

		SpringApplication.run(SpringBootStarter.class, args);
	}
}
