package com.aetna.clinical.cee.controller;
        
import com.aetna.clinical.cee.providerenablement.dto.request.ReadProviderEnablementRequest;
import com.aetna.clinical.cee.providerenablement.dto.response.ReadProviderEnablementResponse;
import com.aetna.clinical.cee.providerenablement.exception.ProviderEnablementException;
import com.aetna.clinical.cee.providerenablement.service.impl.ProviderEnablementServiceImpl;
import com.aetna.clinical.cee.providerenablement.util.DataConverter;
import com.aetna.clinical.cee.providerenablement.util.EncryptionService;
import com.aetna.clinical.cee.providerenablement.util.LoggerAsyncService;
import com.aetna.clinical.cee.providerenablement.util.ProviderEnablementConstant;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
public class ProviderEnablementController {
    final String CLASS_NAME = "ProviderEnablementController";
    private static Logger logger = LoggerFactory.getLogger(ProviderEnablementController.class);

    @Autowired
    private DataConverter objectConverter;

	@Autowired
	EncryptionService encService;

	@Autowired
	LoggerAsyncService asyncLogger;
    
    @Autowired
    private ProviderEnablementServiceImpl providerEnablementServiceImpl;


    @GetMapping(value = "/getHealth")
    public String getHealth() {
        String METHOD_NAME = "getHealth";
        logger.info("  METHOD_NAME={}, CATEGORY=\"HEALTH_CHECK\"",  METHOD_NAME);
        return "Welcome To CEE Provider Enablement Application";
    }

    @PostMapping(value = "/delegationatribution", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ReadProviderEnablementResponse> getProviderEnablementDetails(@RequestBody ReadProviderEnablementRequest request, @RequestHeader HttpHeaders headers) throws Exception {
        String METHOD_NAME = "getProviderEnablementDetails";
        String transactionId = null;
        String memberId = null;
        ReadProviderEnablementResponse providerEnablementResponse = null;        

        Date date = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyymmddhhmmss");
        String timestamp = df.format(date);
               
        try {
            StopWatch providerEnablementTime = new StopWatch();
            providerEnablementTime.start();            
            transactionId = headers.getFirst(ProviderEnablementConstant.TRANSACTION_ID);
            logger.info( "METHOD_NAME={}, CEE_TRANSACTION_ID={}, ",  METHOD_NAME, transactionId);
            // Add validations if needed here

            
            memberId = request.getMemberID().getIdValue();
            if(memberId != null && !memberId.isEmpty()) {
            	providerEnablementResponse = providerEnablementServiceImpl.SaveProviderEnablementDetails(transactionId, memberId);
            }
            else {
            	logger.error("METHOD_NAME={}, ProviderEnablement input validation failed  for Transaction Id - {}", METHOD_NAME, transactionId);
				throw new ProviderEnablementException(ProviderEnablementConstant.CODE_400, ProviderEnablementConstant.CODE_400_MESSAGE, ProviderEnablementConstant.CODE_400_INFO);
            }
            

            if (providerEnablementResponse != null ) {
            	providerEnablementTime.stop();
                asyncLogger.logControllerStatements(logger, objectConverter.convertToJson(providerEnablementResponse), memberId, transactionId, providerEnablementTime);
            } else {
            	providerEnablementTime.stop();
            	asyncLogger.logControllerStatements(logger, null, memberId, transactionId, providerEnablementTime);
				throw new ProviderEnablementException(ProviderEnablementConstant.CODE_500, ProviderEnablementConstant.CODE_500_MESSAGE, ProviderEnablementConstant.CODE_500_INFO);
            }
            logger.info(" METHOD_NAME={}, CEE_TRANSACTION_ID={},  TYPE=\"RESPONSE_TIME\", INFO={}ms",  METHOD_NAME, transactionId, providerEnablementTime);
        }catch(ProviderEnablementException providerEnablementException){
            logger.error("METHOD_NAME={}, ProviderEnablementException in ProviderEnablement controller for  Transaction Id - {}, error message {} >>>" , METHOD_NAME, transactionId,  providerEnablementException.getMoreInformation());
            throw providerEnablementException;

        }catch(Exception genericException) {
            logger.error("METHOD_NAME={}, GenericException in ProviderEnablement controller for  Transaction Id - {}, error message {} >>>" , METHOD_NAME, transactionId, genericException.getMessage());
            throw genericException;
        }

        return new ResponseEntity<ReadProviderEnablementResponse>(providerEnablementResponse, HttpStatus.OK);
            }
}
