package com.aetna.clinical.cee.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


 @RestController
 public class TestController {

   private static final Logger logger = LoggerFactory.getLogger(TestController.class);

   @GetMapping(value = "/")
   public String homepage() {
       logger.info("Welcome to CEE FallOutTransactionsList microservice");
       return "Welcome to CEE FallOutTransactionsList Test microservice";
   }

  /* @PostMapping(value = "/ceeproviderenableenablement",consumes = MediaType.APPLICATION_JSON_VALUE)
     public ResponseEntity<FallOutTransactionsListResponseDTO> getFallOutTransactionsListResponse(){
       final String METHOD_NAME="getFallOutTransactionsListResponse";

       return null;
   }*/
 }
